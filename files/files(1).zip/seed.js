// Populates muster.db with sample data matching the mockup screens.
// Run once with: npm run seed
const Database = require("better-sqlite3");
const fs = require("fs");
const path = require("path");
const { hashPassword } = require("./auth");

const DEMO_PASSWORD = "password123"; // demo accounts only — never do this for real users

const dbPath = path.join(__dirname, "muster.db");
const isNew = !fs.existsSync(dbPath);
const db = new Database(dbPath);
db.pragma("foreign_keys = ON");

// Always (re)build schema fresh for local dev/test convenience.
db.exec(fs.readFileSync(path.join(__dirname, "reset.sql"), "utf8"));
db.exec(fs.readFileSync(path.join(__dirname, "schema.sql"), "utf8"));

const insertFarmer = db.prepare(
  `INSERT INTO farmers (name, email, phone, password_hash) VALUES (?, ?, ?, ?)`
);
const farmerId = insertFarmer.run(
  "Nathan Hambly", "nathan@example.com", "0400 000 000", hashPassword(DEMO_PASSWORD)
).lastInsertRowid;

const insertProperty = db.prepare(`
  INSERT INTO properties
    (farmer_id, name, pic_code, address, suburb, latitude, longitude,
     size_hectares, access_notes, permitted_hours, allow_spotlighting)
  VALUES (@farmer_id, @name, @pic_code, @address, @suburb, @latitude, @longitude,
          @size_hectares, @access_notes, @permitted_hours, @allow_spotlighting)
`);
const propertyId = insertProperty.run({
  farmer_id: farmerId,
  name: "Riverbend",
  pic_code: "3TR00412",
  address: "1420 Mansfield-Woods Point Rd",
  suburb: "Mansfield",
  latitude: -37.0503,
  longitude: 146.0888,
  size_hectares: 412,
  access_notes: "Main gate code 4471#. Track suitable for 4WD only after rain.",
  permitted_hours: "05:30-09:00,16:00-dusk",
  allow_spotlighting: 0,
}).lastInsertRowid;

db.prepare(
  `INSERT INTO no_go_zones (property_id, label, description) VALUES (?, ?, ?)`
).run(propertyId, "House paddock", "Excludes house paddock and dam frontage");

const insertSighting = db.prepare(`
  INSERT INTO sightings (property_id, species, estimated_count, damage_notes, urgent)
  VALUES (?, ?, ?, ?, ?)
`);
insertSighting.run(propertyId, "Sambar", 6, "Fence damage along the eastern boundary", 0);
insertSighting.run(propertyId, "Fallow", 3, "Crop damage in the lower paddock", 1);

const insertHunter = db.prepare(`
  INSERT INTO hunters
    (name, email, phone, password_hash, bio, latitude, longitude, thermal_capable, suppressed_capable, is_active)
  VALUES (@name, @email, @phone, @password_hash, @bio, @latitude, @longitude, @thermal_capable, @suppressed_capable, 1)
`);

const hunters = [
  {
    name: "Tom Riordan",
    email: "tom@example.com",
    phone: "0411 111 111",
    password_hash: hashPassword(DEMO_PASSWORD),
    bio: "Ten years harvesting Sambar and Fallow across the King Valley. Full field depot rig, quiet on approach.",
    latitude: -37.0, longitude: 146.05,
    thermal_capable: 1, suppressed_capable: 1,
  },
  {
    name: "Jess McAllister",
    email: "jess@example.com",
    phone: "0422 222 222",
    password_hash: hashPassword(DEMO_PASSWORD),
    bio: "Based out of Alexandra, mostly Sambar country.",
    latitude: -37.19, longitude: 145.71,
    thermal_capable: 1, suppressed_capable: 0,
  },
  {
    name: "Dale Kovac",
    email: "dale@example.com",
    phone: "0433 333 333",
    password_hash: hashPassword(DEMO_PASSWORD),
    bio: "Long-time contract shooter, five-star record.",
    latitude: -37.28, longitude: 146.32,
    thermal_capable: 0, suppressed_capable: 0,
  },
];

const hunterIds = hunters.map((h) => insertHunter.run(h).lastInsertRowid);

const insertCredential = db.prepare(`
  INSERT INTO credentials
    (hunter_id, credential_type, reference_number, issuer, issued_date, expiry_date, status, verified_by_admin, verified_at)
  VALUES (@hunter_id, @credential_type, @reference_number, @issuer, @issued_date, @expiry_date, @status, @verified_by_admin, @verified_at)
`);

const credentialSets = [
  // Tom Riordan — fully verified, suppressor permit expiring soon
  [
    { credential_type: "primesafe_field_harvester", reference_number: "PS-22841", issuer: "PrimeSafe", issued_date: "2024-03-01", expiry_date: "2027-03-01", status: "verified" },
    { credential_type: "game_licence", reference_number: "GL-88213", issuer: "Game Management Authority", issued_date: "2024-06-01", expiry_date: "2027-06-01", status: "verified" },
    { credential_type: "firearms_licence", reference_number: "FA-10234", issuer: "Victoria Police", issued_date: "2022-01-01", expiry_date: "2027-01-01", status: "verified" },
    { credential_type: "vehicle_field_depot", reference_number: "1RB-4KJ", issuer: "PrimeSafe", issued_date: "2024-03-01", expiry_date: "2027-03-01", status: "verified" },
    { credential_type: "public_liability_insurance", reference_number: "PL-556291", issuer: "Rural Insurers Co.", issued_date: "2026-01-15", expiry_date: "2027-01-15", status: "verified" },
    { credential_type: "suppressor_permit", reference_number: "F-90213", issuer: "Victoria Police", issued_date: "2025-08-15", expiry_date: "2026-08-15", status: "warning" },
  ],
  // Jess McAllister — vehicle licence close to expiry
  [
    { credential_type: "primesafe_field_harvester", reference_number: "PS-30112", issuer: "PrimeSafe", issued_date: "2023-11-01", expiry_date: "2026-11-01", status: "verified" },
    { credential_type: "game_licence", reference_number: "GL-77102", issuer: "Game Management Authority", issued_date: "2024-02-01", expiry_date: "2027-02-01", status: "verified" },
    { credential_type: "firearms_licence", reference_number: "FA-22981", issuer: "Victoria Police", issued_date: "2021-05-01", expiry_date: "2026-05-01", status: "verified" },
    { credential_type: "vehicle_field_depot", reference_number: "3XJ-991", issuer: "PrimeSafe", issued_date: "2023-08-10", expiry_date: "2026-08-10", status: "warning" },
    { credential_type: "public_liability_insurance", reference_number: "PL-99213", issuer: "AgriCover", issued_date: "2026-02-01", expiry_date: "2027-02-01", status: "verified" },
  ],
  // Dale Kovac — fully verified, no thermal/suppressor
  [
    { credential_type: "primesafe_field_harvester", reference_number: "PS-11029", issuer: "PrimeSafe", issued_date: "2022-04-01", expiry_date: "2027-04-01", status: "verified" },
    { credential_type: "game_licence", reference_number: "GL-55210", issuer: "Game Management Authority", issued_date: "2024-09-01", expiry_date: "2027-09-01", status: "verified" },
    { credential_type: "firearms_licence", reference_number: "FA-30871", issuer: "Victoria Police", issued_date: "2020-03-01", expiry_date: "2027-03-01", status: "verified" },
    { credential_type: "vehicle_mtv", reference_number: "8KP-220", issuer: "PrimeSafe", issued_date: "2024-01-01", expiry_date: "2027-01-01", status: "verified" },
    { credential_type: "public_liability_insurance", reference_number: "PL-40021", issuer: "Rural Insurers Co.", issued_date: "2026-03-01", expiry_date: "2027-03-01", status: "verified" },
  ],
];

hunterIds.forEach((hunterId, i) => {
  credentialSets[i].forEach((c) =>
    insertCredential.run({
      hunter_id: hunterId,
      verified_by_admin: c.status === "verified" || c.status === "warning" ? "admin" : null,
      verified_at: c.status === "verified" || c.status === "warning" ? c.issued_date : null,
      ...c,
    })
  );
});

const insertBooking = db.prepare(`
  INSERT INTO bookings (property_id, hunter_id, requested_date, start_time, end_time, status, farmer_note)
  VALUES (?, ?, ?, ?, ?, ?, ?)
`);
const bookingId = insertBooking.run(
  propertyId, hunterIds[0], "2026-08-15", "05:30", "09:00", "approved",
  "Livestock in the north paddock this week"
).lastInsertRowid;

db.prepare(`INSERT INTO reviews (booking_id, author_type, rating, comment) VALUES (?, ?, ?, ?)`)
  .run(bookingId, "farmer", 5, "Always closes the gates behind him.");

// bump rating rollups
db.prepare(`
  UPDATE hunters SET rating_avg = 4.9, rating_count = 21 WHERE id = ?
`).run(hunterIds[0]);
db.prepare(`UPDATE hunters SET rating_avg = 4.7, rating_count = 12 WHERE id = ?`).run(hunterIds[1]);
db.prepare(`UPDATE hunters SET rating_avg = 5.0, rating_count = 34 WHERE id = ?`).run(hunterIds[2]);

db.prepare(`
  INSERT INTO referrals (referring_farmer_id, hunter_id, referred_name, referred_contact, referred_property, note, status)
  VALUES (?, ?, ?, ?, ?, ?, ?)
`).run(farmerId, hunterIds[2], "Neighbouring Farmer", "0455 555 555", "Hillcrest Angus, Jamieson", null, "signed_up");

console.log(`Seeded ${dbPath}`);
console.log(`Farmer #${farmerId}, Property #${propertyId}, Hunters: ${hunterIds.join(", ")}`);
console.log(`Demo logins (password: ${DEMO_PASSWORD}):`);
console.log(`  Farmer — nathan@example.com`);
console.log(`  Hunter — tom@example.com / jess@example.com / dale@example.com`);
