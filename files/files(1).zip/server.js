const express = require("express");
const cors = require("cors");
const Database = require("better-sqlite3");
const path = require("path");
const fs = require("fs");
const { hashPassword, verifyPassword, signToken, requireAuth } = require("./auth");

const dbPath = path.join(__dirname, "muster.db");
if (!fs.existsSync(dbPath)) {
  console.error("muster.db not found — run `npm run seed` first.");
  process.exit(1);
}
const db = new Database(dbPath);
db.pragma("foreign_keys = ON");

const app = express();
app.use(cors());
app.use(express.json());

// ---------------------------------------------------------
// Helpers
// ---------------------------------------------------------
function distanceKm(lat1, lon1, lat2, lon2) {
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

function credentialLabel(type) {
  return {
    primesafe_field_harvester: "PRIMESAFE",
    game_licence: "GAME LICENCE",
    firearms_licence: "FIREARMS LICENCE",
    vehicle_field_depot: "VEHICLE",
    vehicle_mtv: "VEHICLE (MTV)",
    public_liability_insurance: "INSURED",
    suppressor_permit: "SUPPRESSOR PERMIT",
  }[type] || type.toUpperCase();
}

// Never send password_hash back to the client.
function omitPassword(row) {
  if (!row) return row;
  const { password_hash, ...rest } = row;
  return rest;
}

// ===========================================================
// AUTH — farmers
// ===========================================================

// POST /api/auth/farmer/register — body: { name, email, phone, password }
app.post("/api/auth/farmer/register", (req, res) => {
  const { name, email, phone, password } = req.body;
  if (!name || !email || !password) {
    return res.status(400).json({ error: "name, email and password are required" });
  }
  if (password.length < 8) {
    return res.status(400).json({ error: "Password must be at least 8 characters" });
  }
  try {
    const result = db
      .prepare(`INSERT INTO farmers (name, email, phone, password_hash) VALUES (?, ?, ?, ?)`)
      .run(name, email, phone || null, hashPassword(password));
    const farmer = db.prepare(`SELECT * FROM farmers WHERE id = ?`).get(result.lastInsertRowid);
    const token = signToken({ id: farmer.id, role: "farmer" });
    res.status(201).json({ token, user: { ...omitPassword(farmer), role: "farmer" } });
  } catch (e) {
    res.status(400).json({
      error: e.message.includes("UNIQUE") ? "A farmer with that email already exists" : e.message,
    });
  }
});

// POST /api/auth/farmer/login — body: { email, password }
app.post("/api/auth/farmer/login", (req, res) => {
  const { email, password } = req.body;
  const farmer = db.prepare(`SELECT * FROM farmers WHERE email = ?`).get(email);
  if (!farmer || !verifyPassword(password || "", farmer.password_hash)) {
    return res.status(401).json({ error: "Invalid email or password" });
  }
  const token = signToken({ id: farmer.id, role: "farmer" });
  res.json({ token, user: { ...omitPassword(farmer), role: "farmer" } });
});

// ===========================================================
// AUTH — hunters
// ===========================================================

// POST /api/auth/hunter/register
// body: { name, email, phone, password, bio, latitude, longitude,
//         thermal_capable, suppressed_capable,
//         credentials: [{ credential_type, reference_number, issuer, issued_date, expiry_date }] }
// New hunters start inactive (is_active = 0) until an admin verifies credentials.
app.post("/api/auth/hunter/register", (req, res) => {
  const {
    name, email, phone, password, bio, latitude, longitude,
    thermal_capable, suppressed_capable, credentials,
  } = req.body;

  if (!name || !email || !password || latitude == null || longitude == null) {
    return res.status(400).json({ error: "name, email, password, latitude and longitude are required" });
  }
  if (password.length < 8) {
    return res.status(400).json({ error: "Password must be at least 8 characters" });
  }

  try {
    const result = db
      .prepare(`
        INSERT INTO hunters
          (name, email, phone, password_hash, bio, latitude, longitude, thermal_capable, suppressed_capable, is_active)
        VALUES (@name, @email, @phone, @password_hash, @bio, @latitude, @longitude, @thermal_capable, @suppressed_capable, 0)
      `)
      .run({
        name, email,
        phone: phone || null,
        password_hash: hashPassword(password),
        bio: bio || null,
        latitude, longitude,
        thermal_capable: thermal_capable ? 1 : 0,
        suppressed_capable: suppressed_capable ? 1 : 0,
      });

    const hunterId = result.lastInsertRowid;

    if (Array.isArray(credentials)) {
      const insertCred = db.prepare(`
        INSERT INTO credentials
          (hunter_id, credential_type, reference_number, issuer, issued_date, expiry_date, status)
        VALUES (?, ?, ?, ?, ?, ?, 'pending')
      `);
      credentials
        .filter((c) => c && c.credential_type && c.reference_number)
        .forEach((c) =>
          insertCred.run(
            hunterId, c.credential_type, c.reference_number,
            c.issuer || null, c.issued_date || null, c.expiry_date || null
          )
        );
    }

    const hunter = db.prepare(`SELECT * FROM hunters WHERE id = ?`).get(hunterId);
    const token = signToken({ id: hunter.id, role: "hunter" });
    res.status(201).json({ token, user: { ...omitPassword(hunter), role: "hunter" } });
  } catch (e) {
    res.status(400).json({
      error: e.message.includes("UNIQUE") ? "A hunter with that email already exists" : e.message,
    });
  }
});

// POST /api/auth/hunter/login — body: { email, password }
app.post("/api/auth/hunter/login", (req, res) => {
  const { email, password } = req.body;
  const hunter = db.prepare(`SELECT * FROM hunters WHERE email = ?`).get(email);
  if (!hunter || !verifyPassword(password || "", hunter.password_hash)) {
    return res.status(401).json({ error: "Invalid email or password" });
  }
  const token = signToken({ id: hunter.id, role: "hunter" });
  res.json({ token, user: { ...omitPassword(hunter), role: "hunter" } });
});

// GET /api/me — current logged-in user, either role, from the token
app.get("/api/me", requireAuth(), (req, res) => {
  if (req.user.role === "farmer") {
    const farmer = db.prepare(`SELECT * FROM farmers WHERE id = ?`).get(req.user.id);
    if (!farmer) return res.status(404).json({ error: "Farmer not found" });
    const properties = db.prepare(`SELECT * FROM properties WHERE farmer_id = ?`).all(farmer.id);
    return res.json({ role: "farmer", ...omitPassword(farmer), properties });
  }
  const hunter = db.prepare(`SELECT * FROM hunters WHERE id = ?`).get(req.user.id);
  if (!hunter) return res.status(404).json({ error: "Hunter not found" });
  hunter.credentials = db.prepare(`SELECT * FROM credentials WHERE hunter_id = ?`).all(hunter.id);
  return res.json({ role: "hunter", ...omitPassword(hunter) });
});

// ===========================================================
// PROPERTIES
// ===========================================================

// GET /api/properties/:id — owner only
app.get("/api/properties/:id", requireAuth("farmer"), (req, res) => {
  const property = db.prepare(`SELECT * FROM properties WHERE id = ?`).get(req.params.id);
  if (!property) return res.status(404).json({ error: "Property not found" });
  if (property.farmer_id !== req.user.id) {
    return res.status(403).json({ error: "You don't have access to this property" });
  }

  property.no_go_zones = db.prepare(`SELECT * FROM no_go_zones WHERE property_id = ?`).all(property.id);
  property.sightings = db
    .prepare(`SELECT * FROM sightings WHERE property_id = ? ORDER BY reported_date DESC`)
    .all(property.id);

  res.json(property);
});

// GET /api/properties/:id/matches — owner only
app.get("/api/properties/:id/matches", requireAuth("farmer"), (req, res) => {
  const property = db.prepare(`SELECT * FROM properties WHERE id = ?`).get(req.params.id);
  if (!property) return res.status(404).json({ error: "Property not found" });
  if (property.farmer_id !== req.user.id) {
    return res.status(403).json({ error: "You don't have access to this property" });
  }

  const hunters = db.prepare(`SELECT * FROM hunters WHERE is_active = 1`).all();
  const credStmt = db.prepare(`SELECT * FROM credentials WHERE hunter_id = ?`);

  const matches = hunters
    .map((h) => {
      const credentials = credStmt.all(h.id);
      return {
        id: h.id,
        name: h.name,
        rating_avg: h.rating_avg,
        rating_count: h.rating_count,
        thermal_capable: !!h.thermal_capable,
        suppressed_capable: !!h.suppressed_capable,
        distance_km: Math.round(
          distanceKm(property.latitude, property.longitude, h.latitude, h.longitude) * 10
        ) / 10,
        credential_tags: credentials.map((c) => ({
          label: credentialLabel(c.credential_type),
          status: c.status,
        })),
      };
    })
    .sort((a, b) => a.distance_km - b.distance_km);

  res.json(matches);
});

// POST /api/properties — logged-in farmer lists a new property
// body: { name, pic_code, address, suburb, latitude, longitude, size_hectares,
//         access_notes, permitted_hours, allow_spotlighting, no_go_zones }
app.post("/api/properties", requireAuth("farmer"), (req, res) => {
  const {
    name, pic_code, address, suburb, latitude, longitude,
    size_hectares, access_notes, permitted_hours, allow_spotlighting, no_go_zones,
  } = req.body;

  if (!name || !pic_code || latitude == null || longitude == null) {
    return res.status(400).json({ error: "name, pic_code, latitude and longitude are required" });
  }

  try {
    const result = db
      .prepare(`
        INSERT INTO properties
          (farmer_id, name, pic_code, address, suburb, latitude, longitude,
           size_hectares, access_notes, permitted_hours, allow_spotlighting)
        VALUES (@farmer_id, @name, @pic_code, @address, @suburb, @latitude, @longitude,
                @size_hectares, @access_notes, @permitted_hours, @allow_spotlighting)
      `)
      .run({
        farmer_id: req.user.id, name, pic_code,
        address: address || null,
        suburb: suburb || null,
        latitude, longitude,
        size_hectares: size_hectares || null,
        access_notes: access_notes || null,
        permitted_hours: permitted_hours || null,
        allow_spotlighting: allow_spotlighting ? 1 : 0,
      });

    const propertyId = result.lastInsertRowid;

    if (Array.isArray(no_go_zones)) {
      const insertZone = db.prepare(
        `INSERT INTO no_go_zones (property_id, label, description) VALUES (?, ?, ?)`
      );
      no_go_zones
        .filter((z) => z && z.label)
        .forEach((z) => insertZone.run(propertyId, z.label, z.description || null));
    }

    res.status(201).json(db.prepare(`SELECT * FROM properties WHERE id = ?`).get(propertyId));
  } catch (e) {
    res.status(400).json({
      error: e.message.includes("UNIQUE") ? "A property with that PIC already exists" : e.message,
    });
  }
});

// ===========================================================
// HUNTERS (public profile view + credential self-service)
// ===========================================================

// GET /api/hunters/:id — any logged-in user can view a hunter's public profile
app.get("/api/hunters/:id", requireAuth(), (req, res) => {
  const hunter = db.prepare(`SELECT * FROM hunters WHERE id = ?`).get(req.params.id);
  if (!hunter) return res.status(404).json({ error: "Hunter not found" });

  hunter.credentials = db.prepare(`SELECT * FROM credentials WHERE hunter_id = ?`).all(hunter.id);
  hunter.reviews = db
    .prepare(
      `SELECT r.* FROM reviews r
       JOIN bookings b ON b.id = r.booking_id
       WHERE b.hunter_id = ? AND r.author_type = 'farmer'
       ORDER BY r.created_at DESC`
    )
    .all(hunter.id);
  hunter.referral_count = db
    .prepare(`SELECT COUNT(*) AS n FROM referrals WHERE hunter_id = ?`)
    .get(hunter.id).n;

  res.json(omitPassword(hunter));
});

// POST /api/hunters/:id/credentials — a hunter adds/updates their own credential
app.post("/api/hunters/:id/credentials", requireAuth("hunter"), (req, res) => {
  if (Number(req.params.id) !== req.user.id) {
    return res.status(403).json({ error: "You can only update your own credentials" });
  }
  const { credential_type, reference_number, issuer, issued_date, expiry_date } = req.body;
  if (!credential_type || !reference_number) {
    return res.status(400).json({ error: "credential_type and reference_number are required" });
  }
  db.prepare(`
    INSERT INTO credentials (hunter_id, credential_type, reference_number, issuer, issued_date, expiry_date, status)
    VALUES (?, ?, ?, ?, ?, ?, 'pending')
    ON CONFLICT(hunter_id, credential_type) DO UPDATE SET
      reference_number = excluded.reference_number,
      issuer = excluded.issuer,
      issued_date = excluded.issued_date,
      expiry_date = excluded.expiry_date,
      status = 'pending',
      verified_by_admin = NULL,
      verified_at = NULL
  `).run(req.params.id, credential_type, reference_number, issuer || null, issued_date || null, expiry_date || null);

  res.status(201).json(db.prepare(`SELECT * FROM credentials WHERE hunter_id = ?`).all(req.params.id));
});

// PATCH /api/hunters/:id — ADMIN ONLY in spirit; there's no admin role
// yet, so this stays unauthenticated for local testing. Before this
// goes anywhere near production, gate it behind a real admin account.
app.patch("/api/hunters/:id", (req, res) => {
  const { is_active, credential_id, credential_status } = req.body;
  if (typeof is_active === "boolean") {
    db.prepare(`UPDATE hunters SET is_active = ? WHERE id = ?`).run(is_active ? 1 : 0, req.params.id);
  }
  if (credential_id && credential_status) {
    db.prepare(`
      UPDATE credentials SET status = ?, verified_by_admin = 'admin', verified_at = datetime('now') WHERE id = ?
    `).run(credential_status, credential_id);
  }
  res.json(omitPassword(db.prepare(`SELECT * FROM hunters WHERE id = ?`).get(req.params.id)));
});

// ===========================================================
// BOOKINGS
// ===========================================================

// POST /api/bookings — logged-in farmer books a hunter on one of their own properties
// body: { property_id, hunter_id, requested_date, start_time, end_time, farmer_note }
app.post("/api/bookings", requireAuth("farmer"), (req, res) => {
  const { property_id, hunter_id, requested_date, start_time, end_time, farmer_note } = req.body;
  if (!property_id || !hunter_id || !requested_date) {
    return res.status(400).json({ error: "property_id, hunter_id and requested_date are required" });
  }
  const property = db.prepare(`SELECT farmer_id FROM properties WHERE id = ?`).get(property_id);
  if (!property || property.farmer_id !== req.user.id) {
    return res.status(403).json({ error: "You can only book on your own properties" });
  }

  const result = db
    .prepare(`
      INSERT INTO bookings (property_id, hunter_id, requested_date, start_time, end_time, farmer_note, status)
      VALUES (?, ?, ?, ?, ?, ?, 'requested')
    `)
    .run(property_id, hunter_id, requested_date, start_time || null, end_time || null, farmer_note || null);

  const booking = db.prepare(`SELECT * FROM bookings WHERE id = ?`).get(result.lastInsertRowid);
  res.status(201).json(booking);
});

// GET /api/bookings/:id — booking + pre-filled declaration data
app.get("/api/bookings/:id", requireAuth(), (req, res) => {
  const booking = db.prepare(`SELECT * FROM bookings WHERE id = ?`).get(req.params.id);
  if (!booking) return res.status(404).json({ error: "Booking not found" });

  const property = db.prepare(`SELECT pic_code, name, farmer_id FROM properties WHERE id = ?`).get(booking.property_id);
  const isOwnerFarmer = req.user.role === "farmer" && property?.farmer_id === req.user.id;
  const isBookedHunter = req.user.role === "hunter" && booking.hunter_id === req.user.id;
  if (!isOwnerFarmer && !isBookedHunter) {
    return res.status(403).json({ error: "You don't have access to this booking" });
  }

  const harvesterCred = db
    .prepare(`SELECT reference_number FROM credentials WHERE hunter_id = ? AND credential_type = 'primesafe_field_harvester'`)
    .get(booking.hunter_id);

  booking.declaration_prefill = {
    pic_code: property?.pic_code,
    property_name: property?.name,
    harvester_approval_no: harvesterCred?.reference_number || null,
  };

  res.json(booking);
});

// PATCH /api/bookings/:id — update status (approve/decline/complete)
app.patch("/api/bookings/:id", requireAuth(), (req, res) => {
  const { status } = req.body;
  const allowed = ["requested", "approved", "declined", "completed", "cancelled"];
  if (!allowed.includes(status)) {
    return res.status(400).json({ error: `status must be one of ${allowed.join(", ")}` });
  }
  db.prepare(`UPDATE bookings SET status = ?, updated_at = datetime('now') WHERE id = ?`)
    .run(status, req.params.id);
  res.json(db.prepare(`SELECT * FROM bookings WHERE id = ?`).get(req.params.id));
});

// ===========================================================
// REFERRALS
// ===========================================================

// POST /api/referrals — logged-in farmer refers a hunter to a neighbour
app.post("/api/referrals", requireAuth("farmer"), (req, res) => {
  const { hunter_id, referred_name, referred_contact, referred_property, note } = req.body;
  if (!hunter_id || !referred_name || !referred_contact) {
    return res.status(400).json({
      error: "hunter_id, referred_name and referred_contact are required",
    });
  }
  const result = db
    .prepare(`
      INSERT INTO referrals (referring_farmer_id, hunter_id, referred_name, referred_contact, referred_property, note, status)
      VALUES (?, ?, ?, ?, ?, ?, 'sent')
    `)
    .run(req.user.id, hunter_id, referred_name, referred_contact, referred_property || null, note || null);

  res.status(201).json(db.prepare(`SELECT * FROM referrals WHERE id = ?`).get(result.lastInsertRowid));
});

// GET /api/referrals — the logged-in farmer's own referral history
app.get("/api/referrals", requireAuth("farmer"), (req, res) => {
  const rows = db
    .prepare(`
      SELECT r.*, h.name AS hunter_name
      FROM referrals r
      JOIN hunters h ON h.id = r.hunter_id
      WHERE r.referring_farmer_id = ?
      ORDER BY r.created_at DESC
    `)
    .all(req.user.id);

  res.json(rows);
});

const PORT = 4000;
app.listen(PORT, () => {
  console.log(`Muster API running at http://localhost:${PORT}`);
});
