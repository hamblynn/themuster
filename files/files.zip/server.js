const express = require("express");
const cors = require("cors");
const Database = require("better-sqlite3");
const path = require("path");
const fs = require("fs");

const dbPath = path.join(__dirname, "muster.db");
if (!fs.existsSync(dbPath)) {
  console.error("muster.db not found — run `npm run seed` first.");
  process.exit(1);
}
const db = new Database(dbPath);
db.pragma("foreign_keys = ON");

const app = express();
app.use(cors());
app.use(express.json());

// ---------------------------------------------------------
// Haversine distance in km between two lat/lng points
// ---------------------------------------------------------
function distanceKm(lat1, lon1, lat2, lon2) {
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

function credentialLabel(type) {
  return {
    primesafe_field_harvester: "PRIMESAFE",
    game_licence: "GAME LICENCE",
    firearms_licence: "FIREARMS LICENCE",
    vehicle_field_depot: "VEHICLE",
    vehicle_mtv: "VEHICLE (MTV)",
    public_liability_insurance: "INSURED",
    suppressor_permit: "SUPPRESSOR PERMIT",
  }[type] || type.toUpperCase();
}

// ---------------------------------------------------------
// GET /api/properties/:id — property + no-go zones + sightings
// ---------------------------------------------------------
app.get("/api/properties/:id", (req, res) => {
  const property = db
    .prepare(`SELECT * FROM properties WHERE id = ?`)
    .get(req.params.id);
  if (!property) return res.status(404).json({ error: "Property not found" });

  property.no_go_zones = db
    .prepare(`SELECT * FROM no_go_zones WHERE property_id = ?`)
    .all(property.id);
  property.sightings = db
    .prepare(
      `SELECT * FROM sightings WHERE property_id = ? ORDER BY reported_date DESC`
    )
    .all(property.id);

  res.json(property);
});

// ---------------------------------------------------------
// GET /api/properties/:id/matches — hunters sorted by distance,
// active only, with credential tags + capability flags
// ---------------------------------------------------------
app.get("/api/properties/:id/matches", (req, res) => {
  const property = db
    .prepare(`SELECT * FROM properties WHERE id = ?`)
    .get(req.params.id);
  if (!property) return res.status(404).json({ error: "Property not found" });

  const hunters = db.prepare(`SELECT * FROM hunters WHERE is_active = 1`).all();
  const credStmt = db.prepare(`SELECT * FROM credentials WHERE hunter_id = ?`);

  const matches = hunters
    .map((h) => {
      const credentials = credStmt.all(h.id);
      return {
        id: h.id,
        name: h.name,
        rating_avg: h.rating_avg,
        rating_count: h.rating_count,
        thermal_capable: !!h.thermal_capable,
        suppressed_capable: !!h.suppressed_capable,
        distance_km: Math.round(
          distanceKm(property.latitude, property.longitude, h.latitude, h.longitude) * 10
        ) / 10,
        credential_tags: credentials.map((c) => ({
          label: credentialLabel(c.credential_type),
          status: c.status,
        })),
      };
    })
    .sort((a, b) => a.distance_km - b.distance_km);

  res.json(matches);
});

// ---------------------------------------------------------
// GET /api/hunters/:id — full profile with credentials + reviews
// ---------------------------------------------------------
app.get("/api/hunters/:id", (req, res) => {
  const hunter = db.prepare(`SELECT * FROM hunters WHERE id = ?`).get(req.params.id);
  if (!hunter) return res.status(404).json({ error: "Hunter not found" });

  hunter.credentials = db
    .prepare(`SELECT * FROM credentials WHERE hunter_id = ?`)
    .all(hunter.id);
  hunter.reviews = db
    .prepare(
      `SELECT r.* FROM reviews r
       JOIN bookings b ON b.id = r.booking_id
       WHERE b.hunter_id = ? AND r.author_type = 'farmer'
       ORDER BY r.created_at DESC`
    )
    .all(hunter.id);
  hunter.referral_count = db
    .prepare(`SELECT COUNT(*) AS n FROM referrals WHERE hunter_id = ?`)
    .get(hunter.id).n;

  res.json(hunter);
});

// ---------------------------------------------------------
// POST /api/bookings — create a booking request
// body: { property_id, hunter_id, requested_date, start_time, end_time, farmer_note }
// ---------------------------------------------------------
app.post("/api/bookings", (req, res) => {
  const { property_id, hunter_id, requested_date, start_time, end_time, farmer_note } = req.body;
  if (!property_id || !hunter_id || !requested_date) {
    return res.status(400).json({ error: "property_id, hunter_id and requested_date are required" });
  }
  const result = db
    .prepare(`
      INSERT INTO bookings (property_id, hunter_id, requested_date, start_time, end_time, farmer_note, status)
      VALUES (?, ?, ?, ?, ?, ?, 'requested')
    `)
    .run(property_id, hunter_id, requested_date, start_time || null, end_time || null, farmer_note || null);

  const booking = db.prepare(`SELECT * FROM bookings WHERE id = ?`).get(result.lastInsertRowid);
  res.status(201).json(booking);
});

// ---------------------------------------------------------
// GET /api/bookings/:id — booking + pre-filled declaration data
// ---------------------------------------------------------
app.get("/api/bookings/:id", (req, res) => {
  const booking = db.prepare(`SELECT * FROM bookings WHERE id = ?`).get(req.params.id);
  if (!booking) return res.status(404).json({ error: "Booking not found" });

  const property = db.prepare(`SELECT pic_code, name FROM properties WHERE id = ?`).get(booking.property_id);
  const harvesterCred = db
    .prepare(`SELECT reference_number FROM credentials WHERE hunter_id = ? AND credential_type = 'primesafe_field_harvester'`)
    .get(booking.hunter_id);

  booking.declaration_prefill = {
    pic_code: property?.pic_code,
    property_name: property?.name,
    harvester_approval_no: harvesterCred?.reference_number || null,
  };

  res.json(booking);
});

// ---------------------------------------------------------
// PATCH /api/bookings/:id — update status (approve/decline/complete)
// body: { status }
// ---------------------------------------------------------
app.patch("/api/bookings/:id", (req, res) => {
  const { status } = req.body;
  const allowed = ["requested", "approved", "declined", "completed", "cancelled"];
  if (!allowed.includes(status)) {
    return res.status(400).json({ error: `status must be one of ${allowed.join(", ")}` });
  }
  db.prepare(`UPDATE bookings SET status = ?, updated_at = datetime('now') WHERE id = ?`)
    .run(status, req.params.id);
  res.json(db.prepare(`SELECT * FROM bookings WHERE id = ?`).get(req.params.id));
});

// ---------------------------------------------------------
// POST /api/referrals — farmer refers a hunter to a neighbour
// body: { referring_farmer_id, hunter_id, referred_name, referred_contact, referred_property, note }
// ---------------------------------------------------------
app.post("/api/referrals", (req, res) => {
  const { referring_farmer_id, hunter_id, referred_name, referred_contact, referred_property, note } = req.body;
  if (!referring_farmer_id || !hunter_id || !referred_name || !referred_contact) {
    return res.status(400).json({
      error: "referring_farmer_id, hunter_id, referred_name and referred_contact are required",
    });
  }
  const result = db
    .prepare(`
      INSERT INTO referrals (referring_farmer_id, hunter_id, referred_name, referred_contact, referred_property, note, status)
      VALUES (?, ?, ?, ?, ?, ?, 'sent')
    `)
    .run(referring_farmer_id, hunter_id, referred_name, referred_contact, referred_property || null, note || null);

  res.status(201).json(db.prepare(`SELECT * FROM referrals WHERE id = ?`).get(result.lastInsertRowid));
});

// ---------------------------------------------------------
// GET /api/referrals?farmer_id=1 — a farmer's referral history
// ---------------------------------------------------------
app.get("/api/referrals", (req, res) => {
  const { farmer_id } = req.query;
  if (!farmer_id) return res.status(400).json({ error: "farmer_id query param required" });

  const rows = db
    .prepare(`
      SELECT r.*, h.name AS hunter_name
      FROM referrals r
      JOIN hunters h ON h.id = r.hunter_id
      WHERE r.referring_farmer_id = ?
      ORDER BY r.created_at DESC
    `)
    .all(farmer_id);

  res.json(rows);
});

// ---------------------------------------------------------
// POST /api/farmers — create a farmer
// body: { name, email, phone }
// ---------------------------------------------------------
app.post("/api/farmers", (req, res) => {
  const { name, email, phone } = req.body;
  if (!name || !email) {
    return res.status(400).json({ error: "name and email are required" });
  }
  try {
    const result = db
      .prepare(`INSERT INTO farmers (name, email, phone) VALUES (?, ?, ?)`)
      .run(name, email, phone || null);
    res.status(201).json(db.prepare(`SELECT * FROM farmers WHERE id = ?`).get(result.lastInsertRowid));
  } catch (e) {
    res.status(400).json({ error: e.message.includes("UNIQUE") ? "A farmer with that email already exists" : e.message });
  }
});

// ---------------------------------------------------------
// POST /api/properties — a farmer lists a new property
// body: { farmer_id, name, pic_code, address, suburb, latitude,
//         longitude, size_hectares, access_notes, permitted_hours,
//         allow_spotlighting, no_go_zones: [{label, description}] }
// ---------------------------------------------------------
app.post("/api/properties", (req, res) => {
  const {
    farmer_id, name, pic_code, address, suburb, latitude, longitude,
    size_hectares, access_notes, permitted_hours, allow_spotlighting, no_go_zones,
  } = req.body;

  if (!farmer_id || !name || !pic_code || latitude == null || longitude == null) {
    return res.status(400).json({
      error: "farmer_id, name, pic_code, latitude and longitude are required",
    });
  }

  try {
    const result = db
      .prepare(`
        INSERT INTO properties
          (farmer_id, name, pic_code, address, suburb, latitude, longitude,
           size_hectares, access_notes, permitted_hours, allow_spotlighting)
        VALUES (@farmer_id, @name, @pic_code, @address, @suburb, @latitude, @longitude,
                @size_hectares, @access_notes, @permitted_hours, @allow_spotlighting)
      `)
      .run({
        farmer_id, name, pic_code,
        address: address || null,
        suburb: suburb || null,
        latitude, longitude,
        size_hectares: size_hectares || null,
        access_notes: access_notes || null,
        permitted_hours: permitted_hours || null,
        allow_spotlighting: allow_spotlighting ? 1 : 0,
      });

    const propertyId = result.lastInsertRowid;

    if (Array.isArray(no_go_zones)) {
      const insertZone = db.prepare(
        `INSERT INTO no_go_zones (property_id, label, description) VALUES (?, ?, ?)`
      );
      no_go_zones
        .filter((z) => z && z.label)
        .forEach((z) => insertZone.run(propertyId, z.label, z.description || null));
    }

    res.status(201).json(db.prepare(`SELECT * FROM properties WHERE id = ?`).get(propertyId));
  } catch (e) {
    res.status(400).json({ error: e.message.includes("UNIQUE") ? "A property with that PIC already exists" : e.message });
  }
});

// ---------------------------------------------------------
// POST /api/hunters — create a hunter profile
// body: { name, email, phone, bio, latitude, longitude,
//         thermal_capable, suppressed_capable,
//         credentials: [{ credential_type, reference_number, issuer, issued_date, expiry_date }] }
// New hunters start inactive (is_active = 0) until an admin
// verifies at least the required credentials.
// ---------------------------------------------------------
app.post("/api/hunters", (req, res) => {
  const {
    name, email, phone, bio, latitude, longitude,
    thermal_capable, suppressed_capable, credentials,
  } = req.body;

  if (!name || !email || latitude == null || longitude == null) {
    return res.status(400).json({ error: "name, email, latitude and longitude are required" });
  }

  try {
    const result = db
      .prepare(`
        INSERT INTO hunters
          (name, email, phone, bio, latitude, longitude, thermal_capable, suppressed_capable, is_active)
        VALUES (@name, @email, @phone, @bio, @latitude, @longitude, @thermal_capable, @suppressed_capable, 0)
      `)
      .run({
        name, email,
        phone: phone || null,
        bio: bio || null,
        latitude, longitude,
        thermal_capable: thermal_capable ? 1 : 0,
        suppressed_capable: suppressed_capable ? 1 : 0,
      });

    const hunterId = result.lastInsertRowid;

    if (Array.isArray(credentials)) {
      const insertCred = db.prepare(`
        INSERT INTO credentials
          (hunter_id, credential_type, reference_number, issuer, issued_date, expiry_date, status)
        VALUES (?, ?, ?, ?, ?, ?, 'pending')
      `);
      credentials
        .filter((c) => c && c.credential_type && c.reference_number)
        .forEach((c) =>
          insertCred.run(
            hunterId, c.credential_type, c.reference_number,
            c.issuer || null, c.issued_date || null, c.expiry_date || null
          )
        );
    }

    res.status(201).json(db.prepare(`SELECT * FROM hunters WHERE id = ?`).get(hunterId));
  } catch (e) {
    res.status(400).json({ error: e.message.includes("UNIQUE") ? "A hunter with that email already exists" : e.message });
  }
});

// ---------------------------------------------------------
// POST /api/hunters/:id/credentials — add/replace one credential
// (e.g. hunter completing their profile after initial signup)
// body: { credential_type, reference_number, issuer, issued_date, expiry_date }
// ---------------------------------------------------------
app.post("/api/hunters/:id/credentials", (req, res) => {
  const { credential_type, reference_number, issuer, issued_date, expiry_date } = req.body;
  if (!credential_type || !reference_number) {
    return res.status(400).json({ error: "credential_type and reference_number are required" });
  }
  db.prepare(`
    INSERT INTO credentials (hunter_id, credential_type, reference_number, issuer, issued_date, expiry_date, status)
    VALUES (?, ?, ?, ?, ?, ?, 'pending')
    ON CONFLICT(hunter_id, credential_type) DO UPDATE SET
      reference_number = excluded.reference_number,
      issuer = excluded.issuer,
      issued_date = excluded.issued_date,
      expiry_date = excluded.expiry_date,
      status = 'pending',
      verified_by_admin = NULL,
      verified_at = NULL
  `).run(req.params.id, credential_type, reference_number, issuer || null, issued_date || null, expiry_date || null);

  res.status(201).json(db.prepare(`SELECT * FROM credentials WHERE hunter_id = ?`).all(req.params.id));
});

// ---------------------------------------------------------
// PATCH /api/hunters/:id — admin activation toggle + credential
// status updates, for local testing without a full admin UI.
// body: { is_active?: boolean, credential_id?: number, credential_status?: string }
// ---------------------------------------------------------
app.patch("/api/hunters/:id", (req, res) => {
  const { is_active, credential_id, credential_status } = req.body;
  if (typeof is_active === "boolean") {
    db.prepare(`UPDATE hunters SET is_active = ? WHERE id = ?`).run(is_active ? 1 : 0, req.params.id);
  }
  if (credential_id && credential_status) {
    db.prepare(`
      UPDATE credentials SET status = ?, verified_by_admin = 'admin', verified_at = datetime('now') WHERE id = ?
    `).run(credential_status, credential_id);
  }
  res.json(db.prepare(`SELECT * FROM hunters WHERE id = ?`).get(req.params.id));
});

const PORT = 4000;
app.listen(PORT, () => {
  console.log(`Muster API running at http://localhost:${PORT}`);
});
