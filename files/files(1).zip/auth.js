const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

// Dev-only secret. For anything beyond your own local testing,
// set a real JWT_SECRET environment variable instead — never
// ship this hardcoded fallback to production.
const JWT_SECRET = process.env.JWT_SECRET || "muster-local-dev-secret-change-me";
const TOKEN_EXPIRY = "7d";

function hashPassword(plain) {
  return bcrypt.hashSync(plain, 10);
}

function verifyPassword(plain, hash) {
  return bcrypt.compareSync(plain, hash);
}

function signToken(user) {
  // user: { id, role: 'farmer' | 'hunter' }
  return jwt.sign({ id: user.id, role: user.role }, JWT_SECRET, { expiresIn: TOKEN_EXPIRY });
}

function verifyToken(token) {
  try {
    return jwt.verify(token, JWT_SECRET);
  } catch (e) {
    return null;
  }
}

// Express middleware: requires a valid token, optionally of a
// specific role. Attaches { id, role } to req.user.
function requireAuth(role) {
  return (req, res, next) => {
    const header = req.headers.authorization || "";
    const token = header.startsWith("Bearer ") ? header.slice(7) : null;
    if (!token) return res.status(401).json({ error: "Missing Authorization header" });

    const payload = verifyToken(token);
    if (!payload) return res.status(401).json({ error: "Invalid or expired token" });

    if (role && payload.role !== role) {
      return res.status(403).json({ error: `This action requires a ${role} account` });
    }
    req.user = payload;
    next();
  };
}

module.exports = { hashPassword, verifyPassword, signToken, verifyToken, requireAuth };
